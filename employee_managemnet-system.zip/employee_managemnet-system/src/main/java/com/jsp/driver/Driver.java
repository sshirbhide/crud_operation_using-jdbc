package com.jsp.driver;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import com.jsp.dao.Service;
import com.jsp.entity.Employee;

public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

//		try {
//			Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/first","postgres","root");
//			Statement statement = connection.createStatement();
//			boolean result = statement.execute("create table Employee (id integer primary key , name varchar not null ,age integer not null ,phone bigint, email varchar unique , salary double precision not null , experience double precision not null, department varchar)");
//			System.out.println(result);
//			
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();

//		}
		int option = 1;
		Scanner s = new Scanner(System.in);
		while (option == 1) {
//			Scanner s = new Scanner(System.in);
			System.out.println("*********************welcome**********************");
			System.out.println("1) Enter 1 to Add a new Employee              :");
			System.out.println("2) Enter 2 to Fetch The Existing Employee By id:");
			System.out.println("4) Enter 3 to Update The Existing Employee By id:");
			System.out.println("3) Enter 4 to Delete The Existing Employee By id:");
			int choice = s.nextInt();

			switch (choice) {
			case 1: {

				System.out.println("Enter the Employee id ");
				int id = s.nextInt();
				s.nextLine();
				System.out.println("Enter the Employee name ");
				String name = s.next();
				System.out.println("Enter the Employee age ");
				int age = s.nextInt();
				System.out.println("Enter the Employee phone ");
				long phone = s.nextLong();
				System.out.println("Enter the Employee email ");
				String email = s.next();
				System.out.println("Enter the Employee salary ");
				double salary = s.nextDouble();
				System.out.println("Enter the Employee experience ");
				double Experience = s.nextDouble();
				System.out.println("Enter the Employee department ");
				String department = s.next();

				Employee emp = new Employee(id, name, age, phone, email, salary, Experience, department);

				Service.save(emp);
			}
				break;

			case 2: {

				System.out.println("enter the id");
				int id = s.nextInt();
				Service.fetchById(id);
			}
				break;

			case 3: {
				System.out.println("Enter The Employee ID whose Need to be Updated");
				int id = s.nextInt();
				System.out.println("ENter the age ");
				int age = s.nextInt();
				Service.updateById(id, age);

			}
				break;
			case 4: {
				System.out.println("enter the employee id whose detail need to be deleted");
				int id = s.nextInt();
				Service.deleteById(id);
			}
				break;
			default: {
				System.out.println("please selet the a valid option");
			}
				break;

			}
			System.out.println("*********************************");
			System.out.println("Do you wish to continue ");
			System.out.println("if yes Enter 1: IF not Enter 0");
			option = s.nextInt();
		}
s.close();
	}
}
