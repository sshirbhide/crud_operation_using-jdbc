package com.jsp.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ConnectionPool {
	
	private static List<Connection> connections = new ArrayList<Connection>();
	private static String  url  = "jdbc:postgresql://localhost:5432/first";
	private static String username = "postgres";
	private static String password = "root";
	private static final int POOL_SIZE =5;
	
	static {
		for (int i = 0; i < POOL_SIZE; i++) {
			connections.add(createConnection());
		
			
		}
	}

	private static Connection createConnection() {
		try {
			return DriverManager.getConnection(url,username,password);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null ;
		}
	}
	public static Connection getConnection() {
		if(! connections.isEmpty()) {
			return connections.remove(0);
		}
		else {
			return createConnection();
		}
	}
	public static void receiveConnection(Connection connection) {
		if (connections.size()<POOL_SIZE) {
			connections.add(connection);
		}
		else {
			try {
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
