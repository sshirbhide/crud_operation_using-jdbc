package com.jsp.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.jsp.entity.Employee;

public class Service {

	public static void save(Employee employee) {

		Connection connection = ConnectionPool.getConnection();
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("insert into employee values (?,?,?,?,?,?,?,?)");
			preparedStatement.setInt(1, employee.getId());
			preparedStatement.setString(2, employee.getName());
			preparedStatement.setInt(3, employee.getAge());
			preparedStatement.setLong(4, employee.getPhone());
			preparedStatement.setString(5, employee.getEmail());
			preparedStatement.setDouble(6, employee.getSalary());
			preparedStatement.setDouble(7, employee.getExperience());
			preparedStatement.setString(8, employee.getDepartment());
			int result = preparedStatement.executeUpdate();
			if (result == 1) {
				System.out.println("Employee details are been saved sucessfully");
			} else {
				System.out.println("something went wrong dear");
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

		}

		finally {
			ConnectionPool.receiveConnection(connection);
		}

	}

	public static void fetchById(int id) {
		Connection connection = ConnectionPool.getConnection();

		try {
			PreparedStatement preparedStatement = connection.prepareStatement("select * from employee where id = ?");
			preparedStatement.setInt(1, id);
			ResultSet resultSet = preparedStatement.executeQuery();

			if (resultSet.next()) {
				System.out.println("*************************************");
				System.out.println("employee id is " + resultSet.getInt(1));
				System.out.println("employee Name is " + resultSet.getString(2));
				System.out.println("employee age  is " + resultSet.getInt(3));
				System.out.println("employee phone  is " + resultSet.getLong(4));
				System.out.println("employee id is " + resultSet.getString(5));
				System.out.println("employee id is " + resultSet.getDouble(6));
				System.out.println("employee id is " + resultSet.getDouble(7));
				System.out.println("employee id is " + resultSet.getString(8));
				System.out.println("*************************************");
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	
}
	public static void updateById(int id ,int age) {
		
		Connection connection = ConnectionPool.getConnection();	
		
		try {
			CallableStatement callableStatement = connection.prepareCall("update employee set age = ? where id = ?");
			callableStatement.setInt(1, age);
			callableStatement.setInt(2, id);
			int result = callableStatement.executeUpdate();
			if(result == 1) {
				System.out.println("Emloyee detail has been Sucessfully Updated");
			}
			else {
				System.out.println("employee with Id : "+id+ "Doesnot exists");
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		

	}
	public static void deleteById(int id) {
		Connection connection = ConnectionPool.getConnection();
		
		try {
			CallableStatement statement = connection.prepareCall("delete from employee where id = ?");
			statement.setInt(1,id);
			int result = statement.executeUpdate();
			if (result==1) {
				System.out.println("Employee detail has been Susessfully deleted");
			}
			else {
				System.out.println("employee with Id : "+id+ "Doesnot exists");
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
